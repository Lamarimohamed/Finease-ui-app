package com.example.fintech_ui_tutorial

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
