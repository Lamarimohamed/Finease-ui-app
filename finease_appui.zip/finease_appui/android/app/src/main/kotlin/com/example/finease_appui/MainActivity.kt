package com.example.finease_appui

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
