import 'package:flutter/material.dart';
import '../../../../constants/app_theme.dart';

class RecentTransactions extends StatelessWidget {
  const RecentTransactions({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: AppTheme.spacingL),
      padding: const EdgeInsets.all(AppTheme.spacingL),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(AppTheme.borderRadiusL),
        boxShadow: AppTheme.cardShadow,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Recent Transactions', style: AppTheme.headingSmall),
              TextButton(
                onPressed: () {
                  // TODO: Navigate to transactions history
                },
                child: Text(
                  'See All',
                  style: AppTheme.bodyMedium.copyWith(
                    color: AppTheme.primaryGreen,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: AppTheme.spacingM),
          // Mock transactions - replace with actual data
          _TransactionItem(
            name: 'Sarah Johnson',
            amount: -85.50,
            date: DateTime.now().subtract(const Duration(hours: 2)),
            type: TransactionType.sent,
          ),
          const Divider(height: AppTheme.spacingL),
          _TransactionItem(
            name: 'Michael Chen',
            amount: 150.00,
            date: DateTime.now().subtract(const Duration(hours: 5)),
            type: TransactionType.received,
          ),
          const Divider(height: AppTheme.spacingL),
          _TransactionItem(
            name: 'Coffee Shop',
            amount: -4.50,
            date: DateTime.now().subtract(const Duration(hours: 8)),
            type: TransactionType.sent,
          ),
        ],
      ),
    );
  }
}

enum TransactionType { sent, received }

class _TransactionItem extends StatelessWidget {
  final String name;
  final double amount;
  final DateTime date;
  final TransactionType type;

  const _TransactionItem({
    required this.name,
    required this.amount,
    required this.date,
    required this.type,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 48,
          height: 48,
          decoration: BoxDecoration(
            color:
                type == TransactionType.sent
                    ? AppTheme.errorRed.withOpacity(0.1)
                    : AppTheme.primaryGreen.withOpacity(0.1),
            borderRadius: BorderRadius.circular(AppTheme.borderRadiusM),
          ),
          child: Icon(
            type == TransactionType.sent
                ? Icons.arrow_upward
                : Icons.arrow_downward,
            color:
                type == TransactionType.sent
                    ? AppTheme.errorRed
                    : AppTheme.primaryGreen,
          ),
        ),
        const SizedBox(width: AppTheme.spacingM),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                name,
                style: AppTheme.bodyLarge.copyWith(fontWeight: FontWeight.w600),
              ),
              Text(
                _formatDate(date),
                style: AppTheme.bodySmall.copyWith(color: Colors.grey[600]),
              ),
            ],
          ),
        ),
        Text(
          '${type == TransactionType.sent ? '-' : '+'}\$${amount.abs().toStringAsFixed(2)}',
          style: AppTheme.bodyLarge.copyWith(
            color:
                type == TransactionType.sent
                    ? AppTheme.errorRed
                    : AppTheme.primaryGreen,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }

  String _formatDate(DateTime date) {
    final now = DateTime.now();
    final difference = now.difference(date);

    if (difference.inHours < 24) {
      return '${difference.inHours}h ago';
    } else if (difference.inDays < 7) {
      return '${difference.inDays}d ago';
    } else {
      return '${date.day}/${date.month}/${date.year}';
    }
  }
}
