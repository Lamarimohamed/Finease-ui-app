import 'dart:async';
import 'package:shared_preferences.dart';
import '../models/user_model.dart';

class AuthRepository {
  final SharedPreferences _prefs;
  static const String _userKey = 'user_data';

  AuthRepository(this._prefs);

  Future<UserModel?> getCurrentUser() async {
    final userJson = _prefs.getString(_userKey);
    if (userJson != null) {
      return UserModel.fromJson(
        Map<String, dynamic>.from(Map.from(userJson as Map)),
      );
    }
    return null;
  }

  Future<UserModel> login(String email, String password) async {
    // TODO: Implement actual API call
    // Mock implementation for now
    await Future.delayed(const Duration(seconds: 1));

    if (email != 'test@example.com' || password != 'password123') {
      throw Exception('Invalid credentials');
    }

    final user = UserModel(
      id: '1',
      email: email,
      fullName: 'John Doe',
      phoneNumber: '+1234567890',
      balance: 1000.0,
      profileImage: null,
      createdAt: DateTime.now(),
      lastLogin: DateTime.now(),
    );

    await _saveUser(user);
    return user;
  }

  Future<void> logout() async {
    await _prefs.remove(_userKey);
  }

  Future<UserModel> register({
    required String email,
    required String password,
    required String fullName,
    String? phoneNumber,
  }) async {
    // TODO: Implement actual API call
    // Mock implementation for now
    await Future.delayed(const Duration(seconds: 1));

    final user = UserModel(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      email: email,
      fullName: fullName,
      phoneNumber: phoneNumber,
      balance: 0.0,
      profileImage: null,
      createdAt: DateTime.now(),
      lastLogin: DateTime.now(),
    );

    await _saveUser(user);
    return user;
  }

  Future<void> _saveUser(UserModel user) async {
    await _prefs.setString(_userKey, user.toJson().toString());
  }

  Future<void> updateUser(UserModel user) async {
    await _saveUser(user);
  }
}
